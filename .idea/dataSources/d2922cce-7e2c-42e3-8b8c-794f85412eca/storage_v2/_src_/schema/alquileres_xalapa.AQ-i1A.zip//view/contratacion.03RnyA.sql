create definer = root@localhost view contratacion as
select `alquileres_xalapa`.`agencia`.`colonia`    AS `colonia`,
       `alquileres_xalapa`.`agencia`.`calle`      AS `calle`,
       `alquileres_xalapa`.`agencia`.`num`        AS `num`,
       `alquileres_xalapa`.`agencia`.`cod_postal` AS `cod_postal`,
       `alquileres_xalapa`.`agencia`.`telefono`   AS `telefono`
from `alquileres_xalapa`.`agencia`;

