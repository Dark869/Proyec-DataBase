create definer = root@localhost trigger iva
    before update
    on alquiler
    for each row
begin
			set new.import_men = new.import_men + new.import_men*0.05;
		end;

